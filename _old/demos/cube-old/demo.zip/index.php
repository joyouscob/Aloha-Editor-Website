<!DOCTYPE html>
<html dir="ltr" lang="en-US" id="paulrhayes-com" class="noJs">
<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>3D CSS cube with rotating navigation</title>
	<script src="jquery-1.5.min.js"></script>
	<script>GENTICS_Aloha_base="aloha/";</script>
	<script type="text/javascript" src="aloha/aloha.js"></script>
	<script type="text/javascript" src="aloha/plugins/com.gentics.aloha.plugins.Format/plugin.js"></script>
	<script type="text/javascript" src="aloha/plugins/com.gentics.aloha.plugins.Table/plugin.js"></script>
	<script type="text/javascript" src="aloha/plugins/com.gentics.aloha.plugins.List/plugin.js"></script>
	<script type="text/javascript" src="aloha/plugins/com.gentics.aloha.plugins.Link/plugin.js"></script>
	<script type="text/javascript" src="aloha/plugins/com.gentics.aloha.plugins.Ribbon/plugin.js"></script>
	<script src="jquery-ui-1.8.9.custom.min.js"></script>
	<style type="text/css">

#experiment {
  	text-shadow: #000000 1px 1px 3px;
	-webkit-perspective: 800; 
	-webkit-perspective-origin: 50% 100px;
}

#cube, #cube2 {
	position: relative;
	margin: 100px auto 0;
	height: 512px;
	width: 512px;
	-webkit-transition: -webkit-transform 2s linear;
	-webkit-transform-style: preserve-3d;
}


#cube #face1,
#cube #face2,
#cube #face3,
#cube #face4,
#cube #face5,
#cube #face6 {
	-webkit-transition: -webkit-transform 2s linear;
	-webkit-transform-style: preserve-3d;
}

#cube .face {
	position: absolute;
	height: 512px;
	width: 512px;
	padding: 0;
	font-size: 27px;
	color: #fff;
	//border: 1px solid #555;
	-webkit-border-radius: 3px;
}   

#cube .content {
	color:#FFFFFF;
	padding: 40px;
	width:432px;
	height:432px;
}

#spacing {
	width:100px;
	height:100px;
}
#cube .one  {
	background-image:url(logos/logo_1.png);
	-webkit-transform: rotateX(90deg) translateZ(256px);
}

#cube .two {
	-webkit-transform: translateZ(266px);
}
#cube #startEl {
	position: absolute;
	background-image:url(logos/logo_main.png);
	width:512px;
 	height:512px;

}
#cube .container {
	width:512px;
 	height:512px;
}
#cube .two .content {
	background-image:url(logos/logo_4.png);
}
#cube .three {
	background-image:url(logos/logo_3.png);
	-webkit-transform: rotateY(90deg) translateZ(256px);
}
#cube .four {
	background-image:url(logos/logo_2.png);
	-webkit-transform: rotateY(180deg) translateZ(256px);
}
#cube .five {
	background-image:url(logos/logo_5.png);
	-webkit-transform: rotateY(-90deg) translateZ(256px);
}
#cube .six {
	background-image:url(logos/logo_6.png);
	-webkit-transform: rotateX(-90deg) rotate(180deg) translateZ(256px) ;
}

#cube .one,
#cube .three,
#cube .four,
#cube .five,
#cube .six {
	background-color: rgba(0, 126, 179, 0.4);
	border: 1px solid #555;
}

/*** Cube 2 ***/
/*
.cube2 {
	height: 312px;
	width: 312px;
	border: 1px solid #555;
	background-color: rgba(0, 126, 179, 0.2);
}   

.cube2 .one  {
	-webkit-transform: rotateX(90deg) translateZ(156px);
}
.cube2 .two {
	-webkit-transform: rotateY(90deg) translateZ(156px);
}
.cube2 .three {
	-webkit-transform: rotateY(90deg) translateZ(156px);
}
.cube2 .four {
	-webkit-transform: rotateY(180deg) translateZ(156px);
}
.cube2 .five {
	-webkit-transform: rotateY(-90deg) translateZ(156px);
}
.cube2 .six {
	-webkit-transform: rotateX(-90deg) rotate(180deg) translateZ(156px) ;
}
*/
</style>	

</head>
<body class="experiment">
<div id="spacing">&nbsp;</div>
<div id="experiment">	
	<div id="cube">
		<div class="face one" id="face1">
			<div class="content editable">
				<h1>Easier.</h1>
				MousepointerYou can edit any website content instantaneously. You see the changes the moment you type. No training necessary to edit content of a website, wiki, blog or any other application.<a href="#easier">Learn more.</a>
			</div>
		</div>
		<div class="face two" id="face2">
			<div class="container">
				<div class="editable" id="startEl">
				
				</div>
				<div class="content editable">
						
				</div>
			</div>
		</div>
		<div class="face three" id="face3">
			<div class="content editable">
				<h1>Faster.</h1>
				80% loading time saved Aloha Editor operates within the DOM of the front end website. You see what you get - while doing it! No fiddling around, no pop-ups. Just fast. <a href="#faster">Learn more.</a>
			</div>
		</div>
		<div class="face four" id="face4">
			<div class="content editable">
				<h1>Better.</h1>
				HTML5 contenteditable Aloha Editor allows you to edit content you would never imagine you can. It is the world's first full featured Editor that allows you to edit dynamic content live and in place. <a href="#demos">Try it out.</a>
			</div>
		</div>
		<div class="face five" id="face5">
			<div class="content editable">
				One face
			</div>
		</div>
		<div class="face six" id="face6">
			<div class="content editable">
				One face
			</div>
		</div>
	</div>
<!--	<div id="cube2">
		<div class="tileone"></div>
		<div class="tiletwo"></div>
		<div class="tilethree">
		<div class="tilefour"></div>
		<div class="tilefive"></div>
		<div class="tilesix"></div>
	</div>-->
</div>	

<script>
$(function(){
	$('a.showExp').live('click', function(evt) {
		evt.preventDefault();
		$('.fallback').fadeOut('slow', function() {
			$('.test').fadeIn('slow');
		});
	});
});


</script>

<script>

var xAngle = 0, yAngle = 0, twoLevel = 100, distStd = 256, distBig = 276, distNow, scaleStd = 1, scaleBig = 1.1, scaleNow;


$('body').keydown(function(evt) {
	switch(evt.keyCode) {
		case 17: // ctrl
			
			$('#cube')[0].style.webkitTransform = "scaleX("+scaleBig+") scaleY("+scaleBig+") translateZ("+distBig+"px)";
			delay(2000);
			$('#cube')[0].style.webkitTransform = "scaleX("+scaleStd+") scaleY("+scaleStd+") translateZ("+distStd+"px)";
			
/*			$('.face').each(function(){
					this.style.webkitTransform = "scaleX("+scaleBig+") scaleY("+scaleBig+") translateZ("+distBig+"px)";
			});
			delay(2000);
			$('.face').each(function(){
					this.style.webkitTransform = "scaleX("+scaleStd+") scaleY("+scaleStd+") translateZ("+distStd+"px)";
			});
*/		case 18: // alt
/*			$('.face').each(function(){
					this.style.webkitTransform = "scaleX(0.8) scaleY(0.8)";
			});
*/			$('#startEl').animate({opacity:0.5}, 2000);
			$('#face2')[0].style.webkitTransform = "scaleX(0.8) scaleY(0.8) rotateX("+xAngle+"deg) rotateY("+yAngle+"deg) translateZ(156px)";
			break;
		case 37: // left
			yAngle -= 90;
			break;
		
		case 38: // up
			xAngle += 90;				
			break;
		
		case 39: // right
			yAngle += 90;
			break;
			
		case 40: // down
			xAngle -= 90;
			break;
	};
	$('#cube')[0].style.webkitTransform = "rotateX("+xAngle+"deg) rotateY("+yAngle+"deg)";
//	$('#cube2')[0].style.webkitTransform = "rotateY("+xAngle+"deg) rotateX("+yAngle+"deg)";
//	$('#cube')[0].style.webkitTransform = "scaleX(1.5) scaleY(0.5)  scaleZ(0.5)";
});


</script>

<script type="text/javascript">
GENTICS.Aloha.settings = {
	logLevels: {'error': false, 'warn': false, 'info': false, 'debug': false},
	errorhandling : false,
	ribbon: false,	
	"i18n": {
		"current": "de" 
	},
	"plugins": {
	 	"com.gentics.aloha.plugins.Format": {
			config			: 	[ 'b', 'i', 'del', 'sub', 'sup', 'p', 'title', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'pre', 'removeFormat' ]
		},
	 	"com.gentics.aloha.plugins.List": { 
			config			:	[ 'ol', 'ul' ]
		},
	 	"com.gentics.aloha.plugins.Link": { 
			config			:	[ 'a' ]
		},
	 	"com.gentics.aloha.plugins.Table": { 
			config			:	[ 'table' ]
		}
  	}
};

$(document).ready(function () {
	$('.editable').aloha();
});

</script>
</body>
</html>
